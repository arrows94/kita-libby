import React, { useEffect, useMemo, useState } from 'react';
import { api } from './api.js';
import Login from './login.jsx';
import { ChipsInput } from './chips.jsx';

const COLOR_PRESETS = [
  { key: 'white', name: 'Weiß', hex: '#ffffff', border:'#d1d5db' },
  { key: 'red', name: 'Rot', hex: '#ef4444' },
  { key: 'orange', name: 'Orange', hex: '#f97316' },
  { key: 'yellow', name: 'Gelb', hex: '#eab308' },
  { key: 'green', name: 'Grün', hex: '#22c55e' },
  { key: 'teal', name: 'Türkis', hex: '#14b8a6' },
  { key: 'blue', name: 'Blau', hex: '#3b82f6' },
  { key: 'purple', name: 'Lila', hex: '#8b5cf6' },
  { key: 'pink', name: 'Pink', hex: '#ec4899' },
  { key: 'brown', name: 'Braun', hex: '#92400e' },
  { key: 'gray', name: 'Grau', hex: '#6b7280' },
  { key: 'black', name: 'Schwarz', hex: '#000000' },
];

export default function App(){
  // Tabs & global
  const [tab, setTab] = useState('search');
  const [books, setBooks] = useState([]);
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [kiosk, setKiosk] = useState(new URLSearchParams(location.search).has('kiosk'));

  // Empfehlungen & Kategorien-Manager
  const [seasonal, setSeasonal] = useState({ season: '', items: [] });
  const [catMeta, setCatMeta] = useState([]);
  const [showCatMgr, setShowCatMgr] = useState(false);
  const [showRecsSettings, setShowRecsSettings] = useState(false);
  const [recSettings, setRecSettings] = useState(null);

  // Reverse Lookup UI state
  const [lookupOpen, setLookupOpen] = useState(false);
  const [lookupFor, setLookupFor] = useState(null);
  const [lookupResults, setLookupResults] = useState([]);
  const [lookupBusy, setLookupBusy] = useState(false);

  // Suche/Filter
  const [showFilters, setShowFilters] = useState(false);
  const [showInventory, setShowInventory] = useState(false);
  const [query, setQuery] = useState('');
  const [catFilter, setCatFilter] = useState([]); // OR
  const [filterColors, setFilterColors] = useState([]);
  const [top, setTop] = useState([]);

  // Mehrfachauswahl + Sammelaktionen
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [bulkColor1, setBulkColor1] = useState('');
  const [bulkColor2, setBulkColor2] = useState('');
  const [bulkColor3, setBulkColor3] = useState('');
  const [bulkCatsAdd, setBulkCatsAdd] = useState([]);
  const [bulkCatsRemove, setBulkCatsRemove] = useState([]);
  const [bulkCatsSet, setBulkCatsSet] = useState([]);

  // Detail-Modal
  const [selectedBook, setSelectedBook] = useState(null);
  function openBook(b){ setSelectedBook(b); }
  function closeBook(){ setSelectedBook(null); }

  // Admin-Form
  const [id, setId] = useState(null);
  const [isbn, setIsbn] = useState('');
  const [title, setTitle] = useState('');
  const [authors, setAuthors] = useState('');
  const [categories, setCategories] = useState([]);
  const [description, setDescription] = useState('');
  const [cover, setCover] = useState('');
  const [color1, setColor1] = useState('');
  const [color2, setColor2] = useState('');
  const [color3, setColor3] = useState('');
  const [loadingIsbn, setLoadingIsbn] = useState(false);

  // Initial data
  useEffect(() => {
    api.getBooks().then(setBooks).catch(console.error);
    api.getTop().then(setTop).catch(()=>setTop([]));
    api.getSeasonal?.().then(setSeasonal).catch(()=>setSeasonal({season:'',items:[]}));
    api.getCatMeta?.().then(setCatMeta).catch(()=>setCatMeta([]));
  }, []);

  // ESC schließt Modal
  useEffect(() => {
    function handleKeyDown(e){ if(e.key === 'Escape') closeBook(); }
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Kategorien-Liste
  const allCategories = useMemo(() => {
    const s = new Set();
    books.forEach(b => (b.categories||[]).forEach(c=>c && s.add(c)));
    return [...s].sort((a,b)=>a.localeCompare(b));
  }, [books]);

  // Filter
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return books.filter(b => {
      const hay = [b.title,(b.authors||[]).join(' '),(b.categories||[]).join(' '),b.description].filter(Boolean).join(' ').toLowerCase();
      const matchesQ = q ? hay.includes(q) : true;
      const matchesCat = catFilter.length ? (b.categories||[]).some(c=>catFilter.includes(c)) : true; // OR
      const matchesColors = filterColors.length ? filterColors.every(c => [b.color1,b.color2,b.color3].includes(c)) : true;
      return matchesQ && matchesCat && matchesColors;
    });
  }, [books, query, catFilter, filterColors]);

  // Admin helpers
  function resetForm(){
    setId(null); setIsbn(''); setTitle(''); setAuthors(''); setCategories([]); setDescription(''); setCover(''); setColor1(''); setColor2(''); setColor3('');
  }
  function startEdit(b){
    setId(b.id); setIsbn(b.isbn||''); setTitle(b.title||''); setAuthors((b.authors||[]).join(', '));
    setCategories(b.categories||[]); setDescription(b.description||''); setCover(b.cover||''); setColor1(b.color1||''); setColor2(b.color2||''); setColor3(b.color3||''); setTab('admin');
    setShowInventory(true);
  }
  async function saveBook(e){
    e?.preventDefault?.();
    const payload = {
      id,
      title: title.trim(),
      authors: authors.split(',').map(s=>s.trim()).filter(Boolean),
      categories: categories.map(s=>s.trim()).filter(Boolean),
      description: description.trim(),
      isbn: isbn.trim(),
      cover: cover.trim(),
      color1: color1 || '',
      color2: color2 || '',
      color3: color3 || '',
    };
    if(!payload.title){ alert('Titel darf nicht leer sein.'); return; }
    try {
      if(id){ await api.updateBook(id, payload, token); }
      else { await api.createBook(payload, token); }
      setBooks(await api.getBooks());
      resetForm();
      setTab('search');
    } catch(e){
      alert(e.message || 'Fehler beim Speichern');
    }
  }
  async function delBook(id){
    if(!confirm('Buch wirklich löschen?')) return;
    try{
      await api.deleteBook(id, token);
      setBooks(await api.getBooks());
      setTop(await api.getTop());
    }catch(e){ alert(e.message || 'Fehler beim Löschen'); }
  }
  async function lookupISBN(){
    if(!isbn.trim()){ alert('Bitte ISBN eingeben.'); return; }
    setLoadingIsbn(true);
    try{
      const info = await api.lookupISBN(isbn.trim());
      if(!title) setTitle(info.title||'');
      if(!authors) setAuthors((info.authors||[]).join(', '));
      if((categories||[]).length===0 && (info.categories||[]).length) setCategories(info.categories.slice(0,3));
      if(!description) setDescription(info.description||'');
      if(!cover) setCover(info.cover||'');
    }catch{ alert('Keine Daten gefunden.'); }
    finally { setLoadingIsbn(false); }
  }
  async function countView(id){
    try{ await api.viewBook?.(id); setTop(await api.getTop()); } catch{}
  }

  // Auswahl
  function toggleSelect(id){
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function clearSelection(){
    setSelectedIds(new Set());
    setBulkColor1(''); setBulkColor2(''); setBulkColor3('');
  }
  async function applyBulkColors(){
    if(selectedIds.size===0){ alert('Keine Bücher ausgewählt.'); return; }
    const payload = {};
    if (bulkColor1 === '__CLEAR__') payload.color1 = null; else if (bulkColor1) payload.color1 = bulkColor1;
    if (bulkColor2 === '__CLEAR__') payload.color2 = null; else if (bulkColor2) payload.color2 = bulkColor2;
    if (bulkColor3 === '__CLEAR__') payload.color3 = null; else if (bulkColor3) payload.color3 = bulkColor3;
    if (Object.keys(payload).length===0){
      alert('Bitte mindestens Farb-Tag 1–3 setzen oder löschen.');
      return;
    }
    const ids = Array.from(selectedIds);
    try{
      await api.bulkUpdateColors(ids, payload, token);
      setBooks(await api.getBooks());
      clearSelection();
      alert('Farb-Tags aktualisiert.');
    }catch(e){
      alert(e.message || 'Sammel-Update fehlgeschlagen');
    }
  }

  // Lookup
  async function openLookup(book){
    setLookupFor(book);
    setLookupOpen(true);
    setLookupBusy(true);
    try{
      const j = await api.lookupByTitle(book.title);
      setLookupResults(j.items || []);
    } catch{ alert('Suche fehlgeschlagen'); }
    finally { setLookupBusy(false); }
  }
  async function applyPick(p){
    if(!lookupFor) return;
    try{
      await api.applyMetadata(lookupFor.id, {
        authors: p.authors || [], description: p.description || '', isbn: p.isbn || '', cover: p.cover || ''
      }, token);
      setBooks(await api.getBooks());
      setTop && setTop(await api.getTop ? await api.getTop() : []);
      setLookupOpen(false);
    } catch{ alert('Übernehmen fehlgeschlagen'); }
  }

  return (
    <div>
      <header>
        <div className="container row" style={{justifyContent:'space-between'}}>
          <h1>Kita-Bibliothek</h1>
          <div className="row wrap">
            <button className={"btn " + (tab==='search'?'primary':'')} onClick={()=>setTab('search')}>Suche</button>
            <button className={"btn " + (tab==='manage'?'primary':'')} onClick={()=>setTab('manage')}>Verwalten</button>
            <button className={"btn " + (tab==='admin'?'primary':'')} onClick={()=>setTab('admin')}>Administration</button>
            <button className="btn" onClick={()=>setKiosk(k=>!k)}>{kiosk ? "Kiosk aus" : "Kiosk an"}</button>
            <button className="btn" onClick={()=>setShowCatMgr(s=>!s)}>{showCatMgr ? "Kategorien schließen" : "Kategorien-Manager"}</button>
            <button className="btn" onClick={async()=>{ setShowRecsSettings(s=>!s); if(!recSettings){ try{ setRecSettings(await api.getRecSettings()); }catch(e){ alert("Konnte Einstellungen nicht laden"); } } }}>{showRecsSettings ? "Empfehlungen schließen" : "Einstellungen Empfehlungen"}</button>
            <Login token={token} onToken={(t)=>{ setToken(t); localStorage.setItem('token', t||''); }} defaultRole="admin" />
          </div>
        </div>
      </header>

      {/* --- TAB: SEARCH --- */}
      {tab==='search' && (
        <>
          {/* Saisonale Empfehlungen */}
          {(!kiosk && seasonal.items && seasonal.items.length > 0) && (
            <div className="container card" style={{ marginTop: 12 }}>
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <h2 style={{ margin: 0 }}>Saisonale Empfehlungen ({seasonal.season})</h2>
                <button className="btn" onClick={async () => setSeasonal(await api.getSeasonal())}>Aktualisieren</button>
              </div>
              <div className="book-grid" style={{ marginTop: 12 }}>
                {seasonal.items.map((b) => (
                  <article key={b.id} className="card" onClick={()=>{ countView(b.id); openBook(b); }}>
                    <div className="row">
                      {b.cover ? (
                        <img loading="lazy" src={b.cover} alt="Cover" style={{ width: 80, height: 110, objectFit: 'cover', borderRadius: 8, border: '1px solid #e5e7eb' }} />
                      ) : (
                        <div style={{ width: 80, height: 110, background: '#f1f5f9', border: '1px solid #e5e7eb', borderRadius: 8 }} />
                      )}
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div className="truncate" style={{ fontWeight: 600 }}>{b.title}</div>
                        <div className="truncate" style={{ fontSize: 13, color: 'var(--muted)' }}>{(b.authors || []).join(', ')}</div>
                        <div style={{ fontSize: 12, color: 'var(--muted)' }}>{(b.categories || []).join(' · ')}</div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          )}

          {/* Suchleiste & Filter */}
          {kiosk ? (
            <div className='grid' style={{gridTemplateColumns:'1fr'}}>
              <input className='input' value={query} onChange={e=>setQuery(e.target.value)} placeholder='Suche…' />
            </div>
          ) : (
            <div className="container">
              <div className="search-row">
                <input
                  className="input"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Titel, Autor*in, Kategorien, Beschreibung..."
                  aria-label="Suche"
                />
                <button className="btn" onClick={()=>setShowFilters(v=>!v)}>
                  {showFilters ? "Filter verbergen" : "Filter anzeigen"}
                </button>
              </div>

              {showFilters && (
                <div className="filter-panel">
                  <div className="filter-grid">
                    {/* Kategorien */}
                    <section>
                      <div className="filter-head">
                        <strong>Kategorien</strong>
                        <div className="filter-actions">
                          {catFilter.length > 0 && (
                            <button className="btn" onClick={()=>setCatFilter([])}>Zurücksetzen</button>
                          )}
                        </div>
                      </div>

                      {catFilter.length > 0 && (
                        <div className="filter-active">
                          {catFilter.map((c)=>(
                            <span key={c} className="chip">
                              {c}
                              <button onClick={()=>setCatFilter(catFilter.filter(x=>x!==c))}>×</button>
                            </span>
                          ))}
                        </div>
                      )}

                      <div className="filter-cats" role="listbox" aria-label="Kategorien wählen">
                        {allCategories.map((c)=>(
                          !catFilter.includes(c) && (
                            <span
                              key={c}
                              className="badge"
                              role="option"
                              onClick={()=>setCatFilter([...catFilter, c])}
                            >
                              {c}
                            </span>
                          )
                        ))}
                        {allCategories.length===0 && (
                          <div style={{color:'var(--muted)', fontSize:13}}>Noch keine Kategorien im Bestand.</div>
                        )}
                      </div>
                    </section>

                    {/* Farben */}
                    <section>
                      <div className="filter-head">
                        <strong>Farben</strong>
                        <div className="filter-actions">
                          {filterColors.length>0 && (
                            <button className="btn" onClick={()=>setFilterColors([])}>Zurücksetzen</button>
                          )}
                        </div>
                      </div>
                      <div className="filter-colors" role="group" aria-label="Farben filtern">
                        {COLOR_PRESETS.map((c)=>{
                          const active = filterColors.includes(c.key);
                          return (
                            <button
                              key={c.key}
                              className="badge"
                              onClick={() =>
                                setFilterColors(p => active ? p.filter(x=>x!==c.key) : [...p, c.key])
                              }
                              title={c.name}
                              style={{
                                background: active ? c.hex || '#fff' : '#fff',
                                color: active ? (c.key === 'white' ? '#111' : '#fff') : 'inherit',
                                borderColor: c.border || 'transparent',
                              }}
                            >
                              <span
                                className="tag-dot"
                                style={{
                                  background: c.hex || '#fff',
                                  border: c.key === 'white' ? '1px solid #d1d5db' : 'none',
                                }}
                              />
                              {c.name}
                            </button>
                          );
                        })}
                      </div>
                    </section>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Trefferliste */}
          <div className="container">
            <div className="book-grid" style={{ marginTop: 12, gridTemplateColumns: kiosk ? 'repeat(auto-fill,minmax(220px,1fr))' : undefined }}>
              {filtered.map((b) => (
                <article key={b.id} className="card" onClick={() => { countView(b.id); openBook(b); }}>
                  <div className="row">
                    {selectMode && (
                      <input
                        type="checkbox"
                        checked={selectedIds.has(b.id)}
                        onChange={(e)=>{ e.stopPropagation(); toggleSelect(b.id); }}
                        style={{marginRight:6}}
                        aria-label={`Buch auswählen: ${b.title}`}
                      />
                    )}
                    {b.cover ? (
                      <img loading="lazy" src={b.cover} sizes="(max-width: 768px) 40vw, 120px" alt="Cover" style={{ width: 80, height: 110, objectFit: 'cover', borderRadius: 8, border: '1px solid #e5e7eb' }} />
                    ) : (
                      <div style={{ width: 80, height: 110, background: '#f1f5f9', border: '1px solid #e5e7eb', borderRadius: 8, display: 'grid', placeItems: 'center', color: '#9ca3af', fontSize: 12 }}>Kein Cover</div>
                    )}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="truncate" style={{ fontWeight: 600 }} title={b.title}>{b.title}</div>
                      <div className="truncate" style={{ fontSize: 13, color: 'var(--muted)' }} title={(b.authors || []).join(', ')}>{(b.authors || []).join(', ')}</div>
                      <div style={{ fontSize: 12, color: 'var(--muted)' }}>{(b.categories || []).join(' · ')}</div>
                      <div className="row" style={{ marginTop: 6, flexWrap: 'wrap' }}>
                        {[b.color1, b.color2, b.color3].filter(Boolean).map((ck, i) => {
                          const c = COLOR_PRESETS.find((x) => x.key === ck);
                          return (
                            <span key={i} className="badge" style={{ background: c?.hex || '#fff', color: ck === 'white' ? '#111' : '#fff', borderColor: c?.border || 'transparent' }}>
                              <span className="tag-dot" style={{ background: c?.hex || '#fff', border: ck === 'white' ? '1px solid #d1d5db' : 'none' }} />
                              {c?.name || ck}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  <p style={{ marginTop: 8, fontSize: 14, color: '#334155' }}>
                    {(b.description || '').slice(0, 180)}{(b.description || '').length > 180 ? '…' : ''}
                  </p>
                  <div className="row wrap" style={{ marginTop: 8, justifyContent: 'space-between', fontSize: 12, color: 'var(--muted)' }}>
                    <span>ISBN: {b.isbn || '–'}</span>
                    {!kiosk && token && (
                      <div className="row wrap">
                        <button className="btn" onClick={(e) => { e.stopPropagation(); startEdit(b); }}>Bearbeiten</button>
                        {localStorage.getItem('role') === 'admin' && (
                          <button className="btn" onClick={(e) => { e.stopPropagation(); delBook(b.id); }} style={{ color: '#b91c1c', borderColor: '#fecaca' }}>Löschen</button>
                        )}
                      </div>
                    )}
                  </div>
                </article>
              ))}
            </div>

            {filtered.length === 0 && <div style={{ textAlign: 'center', color: 'var(--muted)', marginTop: 32 }}>Keine Treffer.</div>}
          </div>

          {/* Detail-Modal */}
          {selectedBook && (
            <div className="modal" role="dialog" aria-modal="true" aria-labelledby="book-title" onClick={closeBook}>
              <div className="modal-content" onClick={(e)=>e.stopPropagation()}>
                <div className="row" style={{justifyContent:'space-between'}}>
                  <h3 id="book-title" style={{margin:0}}>{selectedBook.title}</h3>
                  <div className="row" style={{gap:8}}>
                    <button className="btn" onClick={()=>openLookup(selectedBook)}>Metadaten finden</button>
                    <button className="btn" onClick={closeBook} aria-label="Schließen">Schließen</button>
                  </div>
                </div>
                <div className="row" style={{alignItems:'flex-start', gap:16, marginTop:12}}>
                  {selectedBook.cover ? (
                    <img src={selectedBook.cover} alt="Cover" style={{width:160,height:220,objectFit:'cover',borderRadius:8,border:'1px solid #e5e7eb'}} />
                  ) : (
                    <div style={{width:160,height:220,background:'#f1f5f9',border:'1px solid #e5e7eb',borderRadius:8,display:'grid',placeItems:'center',color:'#9ca3af'}}>Kein Cover</div>
                  )}
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:14,color:'var(--muted)'}}>{(selectedBook.authors||[]).join(', ')||'—'}</div>
                    <div style={{fontSize:13,color:'var(--muted)',margin:'4px 0'}}>ISBN: {selectedBook.isbn||'—'}</div>
                    <div style={{display:'flex',gap:6,flexWrap:'wrap',margin:'6px 0'}}>
                      {(selectedBook.categories||[]).map((c,i)=>(<span key={i} className="chip">{c}</span>))}
                    </div>
                    <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                      {[selectedBook.color1, selectedBook.color2, selectedBook.color3].filter(Boolean).map((ck,i)=>{
                        const c = COLOR_PRESETS.find(x=>x.key===ck);
                        return (
                          <span key={i} className="badge" style={{ background: c?.hex || '#fff', color: ck === 'white' ? '#111' : '#fff', borderColor: c?.border || 'transparent' }}>
                            <span className="tag-dot" style={{ background: c?.hex || '#fff', border: ck === 'white' ? '1px solid #d1d5db' : 'none' }} />
                            {c?.name || ck}
                          </span>
                        )
                      })}
                    </div>
                  </div>
                </div>
                <div style={{marginTop:12,whiteSpace:'pre-wrap',lineHeight:1.5}}>
                  {selectedBook.description || 'Keine Beschreibung vorhanden.'}
                </div>
              </div>
            </div>
          )}

          {/* Lookup-Modal */}
          {lookupOpen && (
            <div className="modal" role="dialog" aria-modal="true" aria-labelledby="lookup-title" onClick={()=>setLookupOpen(false)}>
              <div className="modal-content" onClick={(e)=>e.stopPropagation()}>
                <div className="row" style={{justifyContent:'space-between'}}>
                  <h3 id="lookup-title" style={{margin:0}}>Metadaten zu „{lookupFor?.title}“</h3>
                  <button className="btn" onClick={()=>setLookupOpen(false)}>Schließen</button>
                </div>
                {lookupBusy ? (
                  <div style={{padding:12}}>Lade Ergebnisse…</div>
                ) : (
                  <div className="book-grid" style={{marginTop:12}}>
                    {lookupResults.map((r, i) => (
                      <article key={i} className="card">
                        <div className="row">
                          {r.cover ? <img src={r.cover} alt="Cover" style={{width:80,height:110,objectFit:'cover',borderRadius:8,border:'1px solid #e5e7eb'}}/> : <div style={{width:80,height:110,background:'#f1f5f9',border:'1px solid #e5e7eb',borderRadius:8}}/>}
                          <div style={{flex:1,minWidth:0}}>
                            <div className="truncate" style={{fontWeight:600}}>{r.title}</div>
                            <div className="truncate" style={{fontSize:12,color:'var(--muted)'}}>{(r.authors||[]).join(', ')||'—'}</div>
                            {r.isbn && <div style={{fontSize:12,color:'var(--muted)'}}>ISBN: {r.isbn}</div>}
                            <div style={{fontSize:12, color:'var(--muted)', maxHeight:72, overflow:'auto'}}>{r.description || '—'}</div>
                            <div className="row" style={{marginTop:8, justifyContent:'space-between'}}>
                              <span className="pill">{r.source}</span>
                              <button className="btn" onClick={()=>applyPick(r)}>Übernehmen</button>
                            </div>
                          </div>
                        </div>
                      </article>
                    ))}
                    {lookupResults.length===0 && <div style={{padding:8, color:'var(--muted)'}}>Keine Treffer.</div>}
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}

      {/* --- TAB: MANAGE --- */}
      {tab==='manage' && (
        <main className="container">
          <section className="card">
            <h2>Verwalten</h2>
            <div className="row wrap" style={{gap:12, alignItems:'end'}}>
              <div style={{flex:2, minWidth:280}}>
                <label>Suche</label>
                <input className="input" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Titel, Autor*in, Kategorien, Beschreibung..." />
              </div>
              <div>
                <label>Kategorien (OR)</label>
                <ChipsInput values={catFilter} onChange={setCatFilter} suggestions={allCategories} />
              </div>
              <div>
                <label>Farben (OR)</label>
                <div className="row wrap" style={{gap:6}}>
                  {COLOR_PRESETS.map(c=>{
                    const active = filterColors.includes(c.key);
                    return (
                      <button key={c.key} type="button" className={"badge"+(active?' active':'')}
                        onClick={()=>setFilterColors(p=> active ? p.filter(x=>x!==c.key) : [...p, c.key])}
                        title={c.name}>
                        <span className="tag-dot" style={{background:c.hex, borderColor:c.border||'transparent'}}/>
                        {c.name}
                      </button>
                    )
                  })}
                </div>
              </div>
              <div className="row" style={{gap:8}}>
                <button className="btn" onClick={()=>{ setQuery(''); setCatFilter([]); setFilterColors([]); }}>Filter zurücksetzen</button>
                <button className="btn" onClick={()=>{ const ids=new Set(filtered.map(b=>b.id)); setSelectedIds(ids); setSelectMode(true); }}>Alle Ergebnisse auswählen</button>
                <button className="btn" onClick={()=>{ setSelectedIds(new Set()); setSelectMode(false); }}>Auswahl leeren</button>
              </div>
            </div>
          </section>

          <section className="card">
            <h3>Ergebnisse</h3>
            <div className="grid" style={{gridTemplateColumns:'1fr 1fr 1fr'}}>
              {filtered.map(b => (
                <article key={b.id} className={"card"+(selectedIds.has(b.id)?' selected':'')} onClick={()=>{
                  if(!selectMode) return;
                  setSelectedIds(prev=>{
                    const n = new Set(prev); if(n.has(b.id)) n.delete(b.id); else n.add(b.id); return n;
                  });
                }}>
                  <div className="row" style={{justifyContent:'space-between', alignItems:'start'}}>
                    <div style={{fontWeight:600}}>{b.title}</div>
                    <input type="checkbox" checked={selectedIds.has(b.id)} onChange={()=>{
                      setSelectedIds(prev=>{ const n=new Set(prev); if(n.has(b.id)) n.delete(b.id); else n.add(b.id); return n; });
                    }} />
                  </div>
                  <div className="truncate" style={{fontSize:12,color:'var(--muted)'}}>{(b.authors||[]).join(', ')||'—'}</div>
                  <div className="row wrap" style={{gap:6, marginTop:6}}>
                    {[b.color1,b.color2,b.color3].filter(Boolean).map((ck,i)=>{
                      const c = COLOR_PRESETS.find(x=>x.key===ck);
                      return <span key={i} className="badge" style={{background:c?.hex||'#fff', color: c?.hex ? '#000' : 'var(--fg)'}}>{c?.name||ck}</span>
                    })}
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section className="card">
            <h3>Sammel-Aktionen</h3>
            <div className="grid" style={{gridTemplateColumns:'1fr 1fr 1fr'}}>
              <div>
                <h4>Farb-Tags setzen/löschen</h4>
                <div className="row wrap" style={{gap:12}}>
                  <div>
                    <label>Farb-Tag 1</label>
                    <select value={bulkColor1} onChange={e=>setBulkColor1(e.target.value)}>
                      <option value="">— nicht ändern —</option>
                      <option value="__CLEAR__">— löschen —</option>
                      {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label>Farb-Tag 2</label>
                    <select value={bulkColor2} onChange={e=>setBulkColor2(e.target.value)}>
                      <option value="">— nicht ändern —</option>
                      <option value="__CLEAR__">— löschen —</option>
                      {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label>Farb-Tag 3</label>
                    <select value={bulkColor3} onChange={e=>setBulkColor3(e.target.value)}>
                      <option value="">— nicht ändern —</option>
                      <option value="__CLEAR__">— löschen —</option>
                      {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                    </select>
                  </div>
                </div>
                <button className="btn primary" disabled={selectedIds.size===0} onClick={applyBulkColors}>Farb-Tags anwenden</button>
              </div>

              <div>
                <h4>Kategorien hinzufügen/entfernen</h4>
                <div>
                  <label>Hinzufügen</label>
                  <ChipsInput values={bulkCatsAdd} onChange={setBulkCatsAdd} suggestions={allCategories} />
                </div>
                <div>
                  <label>Entfernen</label>
                  <ChipsInput values={bulkCatsRemove} onChange={setBulkCatsRemove} suggestions={allCategories} />
                </div>
                <button className="btn" disabled={selectedIds.size===0 || (bulkCatsAdd.length===0 && bulkCatsRemove.length===0)} onClick={async()=>{
                  const ids = Array.from(selectedIds);
                  try{
                    await api.bulkCategories(ids, { add: bulkCatsAdd, remove: bulkCatsRemove }, token);
                    alert('Kategorien aktualisiert.');
                    setBooks(await api.getBooks());
                  }catch(e){ alert(e.message || 'Sammel-Update Kategorien fehlgeschlagen'); }
                }}>Hinzufügen/Entfernen anwenden</button>
              </div>

              <div>
                <h4>Kategorien setzen (ersetzen)</h4>
                <div>
                  <label>Neue Kategorien</label>
                  <ChipsInput values={bulkCatsSet} onChange={setBulkCatsSet} suggestions={allCategories} />
                </div>
                <button className="btn" disabled={selectedIds.size===0 || bulkCatsSet.length===0} onClick={async()=>{
                  const ids = Array.from(selectedIds);
                  try{
                    await api.bulkCategories(ids, { set: bulkCatsSet }, token);
                    alert('Kategorien gesetzt.');
                    setBooks(await api.getBooks());
                  }catch(e){ alert(e.message || 'Setzen der Kategorien fehlgeschlagen'); }
                }}>Ersetzen anwenden</button>
              </div>
            </div>
          </section>
        </main>
      )}

      {/* --- TAB: ADMIN --- */}
      {tab==='admin' && (
        <main className="container">
          {!token ? (
            <div className="card">Bitte zuerst einloggen, um Bücher zu bearbeiten.</div>
          ) : (
            <div className="grid" style={{gridTemplateColumns:'2fr 1fr'}}>
              {/* Formular (links) */}
              <section className="card">
                <h2>{id?'Buch bearbeiten':'Buch anlegen'}</h2>
                <form className="grid" style={{gridTemplateColumns:'1fr 1fr'}} onSubmit={saveBook}>
                  <div className="row" style={{gridColumn:'1 / -1', alignItems:'end'}}>
                    <div style={{flex:1}}>
                      <label>ISBN</label>
                      <input className="input" inputMode="numeric" pattern="[0-9Xx\\- ]*" value={isbn} onChange={e=>setIsbn(e.target.value)} placeholder="z. B. 978-3-16-148410-0" />
                    </div>
                    <button type="button" className="btn primary" onClick={lookupISBN} disabled={loadingIsbn}>{loadingIsbn?'Suche…':'ISBN nachschlagen'}</button>
                  </div>

                  <div style={{gridColumn:'1 / -1'}}>
                    <label>Titel*</label>
                    <input className="input" value={title} onChange={e=>setTitle(e.target.value)} required />
                  </div>

                  <div style={{gridColumn:'1 / -1'}}>
                    <label>Autor*innen (durch Komma getrennt)</label>
                    <input className="input" value={authors} onChange={e=>setAuthors(e.target.value)} />
                  </div>

                  <div style={{gridColumn:'1 / -1'}}>
                    <label>Kategorien</label>
                    <ChipsInput values={categories} onChange={setCategories} suggestions={allCategories} />
                  </div>

                  <div>
                    <label>Cover-URL</label>
                    <input className="input" value={cover} onChange={e=>setCover(e.target.value)} placeholder="https://…" />
                  </div>

                  <div style={{gridColumn:'1 / -1'}}>
                    <label>Beschreibung</label>
                    <textarea className="input" rows="5" value={description} onChange={e=>setDescription(e.target.value)} />
                  </div>

                  <div>
                    <label>Farb-Tag 1</label>
                    <select value={color1} onChange={e=>setColor1(e.target.value)}>
                      <option value="">—</option>
                      {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label>Farb-Tag 2 (darf gleich wie 1 sein)</label>
                    <select value={color2} onChange={e=>setColor2(e.target.value)}>
                      <option value="">—</option>
                      {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label>Farb-Tag 3</label>
                    <select value={color3} onChange={e=>setColor3(e.target.value)}>
                      <option value="">—</option>
                      {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                    </select>
                  </div>

                  <div className="row sticky-actions" style={{gridColumn:'1 / -1'}}>
                    <button className="btn primary" type="submit">{id?'Änderungen speichern':'Buch hinzufügen'}</button>
                    {id && <button className="btn" type="button" onClick={resetForm}>Abbrechen</button>}
                  </div>
                </form>
              </section>

              {/* Rechte Spalte + Toolbar */}
              <aside className="grid" style={{gridTemplateRows:'auto auto auto', gap:12}}>
                <div className="card">
                  <h3>Meist angezeigt</h3>
                  {top.length===0 ? <div style={{color:'var(--muted)'}}>Noch keine Daten.</div> : (
                    <ol style={{margin:'8px 0 0 16px', padding:0}}>
                      {top.map(t => (
                        <li key={t.id} style={{margin:'6px 0'}}>
                          <span style={{fontWeight:600}}>{t.title}</span> <span style={{color:'var(--muted)'}}>({t.views||0})</span>
                        </li>
                      ))}
                    </ol>
                  )}
                </div>

                <div className="card">
                  <h3>Mehrfachauswahl</h3>
                  <div className="row wrap">
                    <button className="btn" onClick={()=>{ setSelectMode(v=>!v); if(selectMode) clearSelection(); }}>
                      {selectMode ? 'Auswahlmodus beenden' : 'Auswahlmodus starten'}
                    </button>
                    <span style={{color:'var(--muted)'}}>Ausgewählt: {selectedIds.size}</span>
                  </div>

                  {selectMode && (
                    <div className="grid" style={{gridTemplateColumns:'1fr 1fr'}}>
                      <div>
                        <label>Farb-Tag 1</label>
                        <select value={bulkColor1} onChange={e=>setBulkColor1(e.target.value)}>
                          <option value="">— nicht ändern —</option>
                          <option value="__CLEAR__">— löschen —</option>
                          {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                        </select>
                      </div>
                      <div>
                        <label>Farb-Tag 2</label>
                        <select value={bulkColor2} onChange={e=>setBulkColor2(e.target.value)}>
                          <option value="">— nicht ändern —</option>
                          <option value="__CLEAR__">— löschen —</option>
                          {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                        </select>
                        <div>
                          <label>Farb-Tag 3</label>
                          <select value={bulkColor3} onChange={e=>setBulkColor3(e.target.value)}>
                            <option value="">— nicht ändern —</option>
                            <option value="__CLEAR__">— löschen —</option>
                            {COLOR_PRESETS.map(c=><option key={c.key} value={c.key}>{c.name}</option>)}
                          </select>
                        </div>
                      </div>
                      <div style={{gridColumn:'1 / -1'}} className="row">
                        <button className="btn primary" disabled={selectedIds.size===0} onClick={applyBulkColors}>
                          Farb-Tags auf Auswahl anwenden
                        </button>
                        <button className="btn" disabled={selectedIds.size===0} onClick={clearSelection}>Auswahl leeren</button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="card">
                  <h3>Import / Export</h3>
                  <div className="row wrap" style={{flexWrap:'wrap'}}>
                    <button className="btn" onClick={async()=>{
                      try{
                        const blob = await api.exportCSV();
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url; a.download = 'kita_books.csv'; a.click();
                        URL.revokeObjectURL(url);
                      }catch(e){ alert('Export fehlgeschlagen'); }
                    }}>CSV Export</button>

                    {token && (localStorage.getItem('role')==='admin') && (
                      <>
                        <input id="csvFile" type="file" accept=".csv,text/csv" className="hidden" onChange={async e=>{
                          const file = e.target.files?.[0];
                          if(!file) return;
                          const text = await file.text();
                          try{
                            const res = await api.importCSV(text, token);
                            alert(`Importiert: ${res.imported}`);
                            setBooks(await api.getBooks());
                            setTop(await api.getTop());
                          }catch(err){ alert('Import fehlgeschlagen: ' + (err.message||'')); }
                        }} />
                        <button className="btn" onClick={()=>document.getElementById('csvFile').click()}>CSV Import</button>
                      </>
                    )}
                  </div>
                  <p style={{fontSize:12,color:'var(--muted)'}}>CSV ist Semikolon-getrennt; Export enthält Kategorien & Views. Import nur für Admins.</p>

                  <div className="card" style={{marginTop:12}}>
                    <h3>Metadaten anreichern</h3>
                    <div className="row wrap">
                      <button className="btn" onClick={async()=>{
                        try{
                          const res = await api.enrichMissing(true, token);
                          alert(`Dry-Run: ${res.count} Bücher mit Kandidaten gefunden.`);
                        }catch(e){ alert('Enrichment fehlgeschlagen'); }
                      }}>Dry-Run prüfen</button>
                      <button className="btn" onClick={async()=>{
                        if(!confirm('Automatisch passende Metadaten übernehmen?')) return;
                        try{
                          const res = await api.enrichMissing(false, token);
                          alert(`Übernommen: ${res.count}`);
                          setBooks(await api.getBooks());
                          setTop(await api.getTop());
                        }catch(e){ alert('Enrichment fehlgeschlagen'); }
                      }}>Automatisch übernehmen</button>
                    </div>
                    <p style={{fontSize:12,color:'var(--muted)'}}>Hinweis: Exakter Titel bevorzugt, sonst erster Treffer.</p>
                  </div>
                </div>
              </aside>

              {/* Bestand unten ausklappbar */}
              <div className="card" style={{gridColumn:'1 / -1'}}>
                <div className="row" style={{justifyContent:'space-between'}}>
                  <h3 style={{margin:0}}>Bestand ({books.length})</h3>
                  <button
                    className="btn small"
                    type="button"
                    onClick={()=>setShowInventory(v=>!v)}
                    aria-expanded={showInventory}
                    aria-controls="bestand-collapse"
                  >
                    {showInventory ? "Bestand verbergen" : "Bestand anzeigen"}
                  </button>
                </div>

                <div id="bestand-collapse" className={`collapse ${showInventory ? 'open' : ''}`} style={{marginTop:8}}>
                  <div style={{maxHeight:'60vh', overflow:'auto', borderTop:'1px solid #e5e7eb', paddingTop:8}}>
                    {books.map(b=>(
                      <div key={b.id} className="row item" style={{borderBottom:'1px solid #e5e7eb', padding:'6px 0'}}>
                        {selectMode && (
                          <input
                            type="checkbox"
                            checked={selectedIds.has(b.id)}
                            onChange={()=>toggleSelect(b.id)}
                            aria-label={`Buch auswählen: ${b.title}`}
                          />
                        )}
                        <div className="thumb" style={{width:24,height:34,background:'#f1f5f9',border:'1px solid #e5e7eb',borderRadius:4,overflow:'hidden'}}>
                          {b.cover ? <img src={b.cover} style={{width:'100%',height:'100%',objectFit:'cover'}}/> : null}
                        </div>
                        <div style={{flex:1,minWidth:0}}>
                          <div className="truncate" style={{fontSize:13,fontWeight:600}}>{b.title}</div>
                          <div className="truncate" style={{fontSize:11,color:'var(--muted)'}}>{(b.authors||[]).join(', ')}</div>
                          <div className="truncate" style={{fontSize:11,color:'var(--muted)'}}>{(b.categories||[]).join(' · ')}</div>
                        </div>
                        {token && <button className="btn small" onClick={()=>startEdit(b)}>Bearbeiten</button>}
                      </div>
                    ))}
                    {books.length===0 && <div style={{color:'var(--muted)', fontSize:13}}>Noch keine Bücher.</div>}
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      )}

      <footer className="container" style={{textAlign:'center',fontSize:12,color:'var(--muted)',padding:'24px 0'}}>
        © {new Date().getFullYear()} Kita-Bibliothek
      </footer>

      {/* Kategorien-Manager */}
      {showCatMgr && (
        <div className="card" style={{margin:12}}>
          <div className="container">
            <h3>Kategorien-Manager</h3>
            <div style={{maxHeight:'40vh', overflow:'auto'}}>
              {catMeta.map(m => (
                <div key={m.name} className="row" style={{borderBottom:'1px solid var(--border)', padding:'6px 0'}}>
                  <span className="badge" style={{background:m.color||'#fff'}}>{m.name} <span style={{fontSize:12,color:'var(--muted)'}}>({m.count})</span></span>
                  <input className="input" style={{width:120}} type="color" value={m.color||'#ffffff'} onChange={async e=>{
                    const color = e.target.value;
                    await api.setCatColor?.(m.name, color);
                    setCatMeta(await api.getCatMeta?.());
                  }} />
                  <input className="input" style={{width:200}} placeholder="Umbenennen zu…" onKeyDown={async e=>{
                    if(e.key==='Enter' && e.target.value.trim()){
                      const to = e.target.value.trim();
                      if(confirm(`Kategorie "${m.name}" zu "${to}" umbenennen?`)){
                        await api.renameCategory?.(m.name, to, token);
                        setCatMeta(await api.getCatMeta?.());
                        setBooks(await api.getBooks());
                        e.target.value = '';
                      }
                    }
                  }} />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Empfehlungen – Einstellungen */}
      {showRecsSettings && (
        <div className="card" style={{margin:12}}>
          <div className="container">
            <h3>Empfehlungen – Einstellungen</h3>
            {!recSettings ? (
              <div style={{color:'var(--muted)'}}>Lade Einstellungen…</div>
            ) : (
              <form className="grid" style={{gridTemplateColumns:'1fr 1fr', gap:12}} onSubmit={async (e)=>{
                e.preventDefault();
                try{
                  const payload = {
                    enabled: e.target.enabled.checked,
                    weightKeyword: parseInt(e.target.weightKeyword.value,10)||0,
                    weightView: parseInt(e.target.weightView.value,10)||0,
                    maxItems: parseInt(e.target.maxItems.value,10)||12,
                    keywords: {
                      winter: e.target.kw_winter.value.split(',').map(s=>s.trim()).filter(Boolean),
                      fruehling: e.target.kw_fruehling.value.split(',').map(s=>s.trim()).filter(Boolean),
                      sommer: e.target.kw_sommer.value.split(',').map(s=>s.trim()).filter(Boolean),
                      herbst: e.target.kw_herbst.value.split(',').map(s=>s.trim()).filter(Boolean),
                    }
                  };
                  const saved = await api.saveRecSettings?.(payload, token);
                  setRecSettings(saved);
                  alert('Einstellungen gespeichert.');
                }catch(err){ alert(err.message || 'Speichern fehlgeschlagen'); }
              }}>
                <div className="row" style={{gridColumn:'1 / -1', alignItems:'center', gap:12}}>
                  <label className="row"><input type="checkbox" name="enabled" defaultChecked={!!recSettings.enabled} /> Empfehlungen aktivieren</label>
                </div>
                <div>
                  <label>Punkte pro Keyword</label>
                  <input className="input" type="number" name="weightKeyword" defaultValue={recSettings.weightKeyword||3} min="0" />
                </div>
                <div>
                  <label>View-Bonus (Faktor)</label>
                  <input className="input" type="number" name="weightView" defaultValue={recSettings.weightView||1} min="0" />
                </div>
                <div>
                  <label>Max. Anzahl Bücher</label>
                  <input className="input" type="number" name="maxItems" defaultValue={recSettings.maxItems||12} min="1" max="50" />
                </div>
                <div style={{gridColumn:'1 / -1'}}><hr/></div>
                <div style={{gridColumn:'1 / -1'}}><strong>Schlüsselwörter (Komma-getrennt)</strong></div>
                <div>
                  <label>Winter</label>
                  <textarea className="input" rows="2" name="kw_winter" defaultValue={(recSettings.keywords?.winter||[]).join(', ')} />
                </div>
                <div>
                  <label>Frühling</label>
                  <textarea className="input" rows="2" name="kw_fruehling" defaultValue={(recSettings.keywords?.fruehling||[]).join(', ')} />
                </div>
                <div>
                  <label>Sommer</label>
                  <textarea className="input" rows="2" name="kw_sommer" defaultValue={(recSettings.keywords?.sommer||[]).join(', ')} />
                </div>
                <div>
                  <label>Herbst</label>
                  <textarea className="input" rows="2" name="kw_herbst" defaultValue={(recSettings.keywords?.herbst||[]).join(', ')} />
                </div>
                <div className="row sticky-actions" style={{gridColumn:'1 / -1'}}>
                  <button className="btn primary" type="submit">Speichern</button>
                  <button className="btn" type="button" onClick={async()=>{ try{ setRecSettings(await api.getRecSettings?.()); alert('Zurückgesetzt auf gespeicherte Werte.'); }catch(e){ } }}>Zurücksetzen</button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
