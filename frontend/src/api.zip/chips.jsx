import React from 'react'
export function ChipsInput({ values, onChange, suggestions=[] }){
  const [text, setText] = React.useState('')
  const add = (v)=>{ v=v.trim(); if(!v) return; if(!values.includes(v)) onChange([...values, v]); setText('') }
  const remove = (v)=> onChange(values.filter(x=>x!==v))
  const onKey = (e)=>{
    if(e.key==='Enter'){ e.preventDefault(); add(text) }
    if(e.key==='Backspace' && !text && values.length){ remove(values[values.length-1]) }
  }
  return (
    <div>
      <div className="chips">
        {values.map(v=>(<span key={v} className="chip">{v}<button title="Entfernen" onClick={()=>remove(v)}>×</button></span>))}
        <input className="input" value={text} onChange={e=>setText(e.target.value)} onKeyDown={onKey} placeholder="Eingeben und Enter…" />
      </div>
      {suggestions.length>0 && (
        <div className="chips" style={{marginTop:6}}>
          {suggestions.map(s=>(<span key={s} className="badge" onClick={()=>add(s)}>{s}</span>))}
        </div>
      )}
    </div>
  )
}
